#!/bin/sh
# Build and deploy https://mnasati.pages.dev
set -e; cd "$(dirname "$0")"
rm -rf dist && mkdir dist
cp ../index.html ../mnasati-logo.svg _worker.js dist/
cd ../cloudflare && npx wrangler pages deploy ../pages/dist --project-name mnasati --branch main --commit-dirty=true
