// Cloudflare Pages advanced-mode worker for https://mnasati.pages.dev
// Static page from ./ (index.html); /mcp, /download/*, /health are proxied to the
// existing Worker (which holds the R2 + Cloudflare Images bindings).
const UPSTREAM = 'https://mnasati-assets.maxx165902.workers.dev';
export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const p = url.pathname;
    if (p === '/mcp' || p === '/health' || p.startsWith('/download/')) {
      const up = new Request(UPSTREAM + p + url.search, req);
      const res = await fetch(up);
      const ct = res.headers.get('content-type') || '';
      if (p === '/mcp' && /json|event-stream/.test(ct)) {
        // Make download links use this domain
        const body = (await res.text()).split(UPSTREAM).join(url.origin);
        const h = new Headers(res.headers); h.delete('content-length');
        return new Response(body, { status: res.status, headers: h });
      }
      return res;
    }
    return env.ASSETS.fetch(req);
  }
};
