# mnasati.pages.dev (Cloudflare Pages)

Live: https://mnasati.pages.dev  ·  MCP: https://mnasati.pages.dev/mcp

## العربية
- نفس الصفحة على `/` ورابط MCP على `/mcp`. أضف `https://mnasati.pages.dev/mcp` كخادم MCP / موصل في أي ذكاء اصطناعي يدعم MCP (ChatGPT، Claude، Cursor وغيرها).
- `_worker.js` يحوّل `/mcp` و `/download/*` و `/health` إلى الـ Worker الأصلي (`mnasati-assets.maxx165902.workers.dev`) الذي يحمل ربط R2 و Cloudflare Images، ويعيد كتابة روابط التحميل لتكون على `mnasati.pages.dev`.
- للنشر: `./build.sh` (يحتاج `CLOUDFLARE_API_TOKEN`). انشر الـ Worker أولاً إذا غيّرت كود الأدوات (`cd ../cloudflare && npm run deploy`).

## English
- Pages advanced mode: `_worker.js` serves static assets via `env.ASSETS` and proxies `/mcp`, `/download/*`, `/health` to the existing Worker, which keeps the R2 and Images bindings. Download links in responses are rewritten to the request origin.
- Deploy: `./build.sh` copies `../index.html`, the logo and `_worker.js` into `dist/`, then runs `wrangler pages deploy` on the production branch `main`.
