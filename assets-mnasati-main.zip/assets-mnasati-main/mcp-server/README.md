# Mnasati Assets MCP Server

## العربية

خادم MCP يولّد ملفات متجر منصتي (favicon.ico، logo.png، def.png، bg.jpg، cover.jpg) من صورة اللوجو، حتى تقدر تحكي مع أي ذكاء اصطناعي يدعم MCP (ChatGPT، Claude، Cursor وغيرها) وتعطيه الصورة وهو يكمل الشغل.

### التشغيل
```bash
cd mcp-server
npm install
npm start          # يشتغل على http://localhost:3000
```
- رابط الـ MCP هو: `http://localhost:3000/mcp`
- نفس الخادم يعرض صفحة الأداة على `/`، وزر **"نسخ رابط MCP"** في الصفحة يعطيك الرابط الصحيح مباشرة.

### الربط مع أي ذكاء اصطناعي (بدون أي إعداد)
1. أغلب التطبيقات تحتاج رابطاً عاماً بـ HTTPS. للتجربة السريعة:
   `npx cloudflared tunnel --url http://localhost:3000` أو `ngrok http 3000`
   (أو ارفع الخادم على أي استضافة Node مثل Render أو Railway أو VPS).
2. افتح الصفحة من الرابط العام واضغط "نسخ رابط MCP"، أو انسخ `https://<your-domain>/mcp` يدوياً.
3. أضف الرابط كخادم MCP / موصل في أي تطبيق يدعم MCP (تختلف أسماء القوائم حسب التطبيق والإصدار):
   - **ChatGPT:** أضف موصلاً مخصصاً (غالباً من الإعدادات، وقد يلزم وضع المطوّر) واختر بدون مصادقة.
   - **Claude:** أضف موصلاً مخصصاً (custom connector) بالرابط.
   - **Cursor وغيره:** في `mcp.json`: `{"mcpServers":{"mnasati-assets":{"url":"https://<your-domain>/mcp"}}}`
4. بالمحادثة: أرفق اللوجو واكتب مثلاً "اعمل ملفات متجر اسمه X بخلفية بيضاء". الأداة ترجع معاينات ورابط تحميل الـ zip.

> ملاحظة: إذا ما قدر التطبيق يمرر الصورة المرفقة للأداة، أعطه رابط الصورة (`image_url`).

### حماية اختيارية
بشكل افتراضي (`AUTH_MODE=none`) أي شخص معه الرابط يقدر يستخدمه. للحماية:
`AUTH_MODE=token AUTH_TOKEN=كلمة-سرية npm start`. بعدها استخدم الرابط `https://<domain>/mcp?token=كلمة-سرية` أو ترويسة `Authorization: Bearer ...`.

---

## English

An MCP server that turns a logo into the Mnasati store asset pack.

| File | Size |
|---|---|
| `{name}_favicon.ico` | 16/32/64/192 px, circular |
| `{name}_logo.png` | 350×350 px, circular |
| `{name}_def.png` | 1000×1000 px |
| `{name}_bg.jpg` | 533×1080 px, pattern at 5% opacity |
| `{name}_cover.jpg` | 1920×1080 px |

### Run
```bash
npm install
npm start                  # HTTP: http://localhost:3000/mcp  (also serves the web tool at /)
npm run stdio              # stdio transport for desktop MCP clients
npm test                   # SDK client test (with the server running)
```
Environment variables:
- `PORT` (default 3000)
- `AUTH_MODE` = `none` (default) or `token`
- `AUTH_TOKEN`
- `PUBLIC_URL`: base URL used in download links when behind a proxy

### Tools
- `generate_store_assets`
  - Inputs: `store_name`, `image_url` | `image_base64`, optional `cover_image_*`, `background_color` (`#RRGGBB` or `none`), `cover_color`.
  - Returns: PNG previews, a zip as an embedded resource, and a download link.
- `trim_image`: removes empty borders. Options: `threshold`, `padding`.
- `resize_image`: resizes to `width`, `height`. Options: `fit` (contain/cover/fill), `padding`, `background`.
- `remove_region`: makes the rectangle given by `x`, `y`, `width`, `height` transparent.

### Connect any MCP-capable AI
1. Expose the server over public HTTPS, using cloudflared, ngrok, or any Node host.
2. Add `https://<your-domain>/mcp` as an MCP server / connector in any client that supports MCP. Menu names vary by app and version.
   - **ChatGPT:** add a custom connector (developer mode may be required) with no authentication.
   - **Claude:** add a custom connector with the URL.
   - **Cursor / others:** `{"mcpServers":{"mnasati-assets":{"url":"https://<your-domain>/mcp"}}}` in `mcp.json`.
3. CORS is open (`*`) and `OPTIONS` preflight is answered, so browser-based clients work too.

### Hosted version
- Ready to use: https://mnasati.pages.dev/mcp (Cloudflare, see `../pages` and `../cloudflare`).

### Notes
- Download links are kept in memory (last 50) and are lost on restart.
- In this version, `bg.jpg` is a real JPEG. The web page writes PNG data under the .jpg name.
