import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { createServer, downloads } from './server.js';

const PORT = parseInt(process.env.PORT || '3000', 10);
// AUTH_MODE=none (default): anyone with the link can use it. AUTH_MODE=token: requires AUTH_TOKEN (Bearer header or ?token=).
const AUTH_MODE = (process.env.AUTH_MODE || 'none').toLowerCase();
const AUTH_TOKEN = process.env.AUTH_TOKEN || '';
const PUBLIC_URL = (process.env.PUBLIC_URL || '').replace(/\/$/, '');
const siteDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

const app = express();
app.set('trust proxy', true);
app.use(express.json({ limit: '30mb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Mcp-Session-Id, Mcp-Protocol-Version');
  res.setHeader('Access-Control-Expose-Headers', 'Mcp-Session-Id');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

function authorized(req) {
  if (AUTH_MODE !== 'token') return true;
  const h = req.headers.authorization || '';
  return AUTH_TOKEN && (h === `Bearer ${AUTH_TOKEN}` || req.query.token === AUTH_TOKEN);
}
const baseUrlOf = (req) => PUBLIC_URL || `${req.protocol}://${req.get('host')}`;

// Stateless Streamable HTTP: new server + transport per request
app.post('/mcp', async (req, res) => {
  if (!authorized(req)) return res.status(401).json({ jsonrpc: '2.0', error: { code: -32001, message: 'Unauthorized' }, id: null });
  try {
    const server = createServer({ baseUrl: baseUrlOf(req) });
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    res.on('close', () => { transport.close(); server.close(); });
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (err) {
    console.error(err);
    if (!res.headersSent) res.status(500).json({ jsonrpc: '2.0', error: { code: -32603, message: 'Internal server error' }, id: null });
  }
});
const notAllowed = (req, res) => res.status(405).json({ jsonrpc: '2.0', error: { code: -32000, message: 'Method not allowed.' }, id: null });
app.get('/mcp', notAllowed);
app.delete('/mcp', notAllowed);

app.get('/download/:id', (req, res) => {
  const d = downloads.get(req.params.id);
  if (!d) return res.status(404).send('Not found or expired');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(d.name)}"`);
  res.send(d.buf);
});
app.get('/health', (req, res) => res.json({ ok: true }));

// Also serve the web tool, so the page's "Copy MCP link" points at this server automatically
app.use('/mcp-server', (req, res) => res.sendStatus(404));
app.use(express.static(siteDir, { index: 'index.html', dotfiles: 'ignore' }));

app.listen(PORT, () => {
  console.log(`Mnasati MCP server on http://localhost:${PORT}  (MCP endpoint: /mcp, auth: ${AUTH_MODE})`);
});
