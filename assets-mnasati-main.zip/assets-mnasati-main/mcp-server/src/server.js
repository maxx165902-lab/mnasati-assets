import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import sharp from 'sharp';
import { randomUUID } from 'node:crypto';
import { loadImage, generateAssets, trimImage, resizeImage, removeRegion } from './assets.js';

// Generated zips kept in memory for download links (HTTP mode)
export const downloads = new Map();
const MAX_DOWNLOADS = 50;
function keepDownload(name, buf) {
  const id = randomUUID();
  downloads.set(id, { name, buf, at: Date.now() });
  while (downloads.size > MAX_DOWNLOADS) downloads.delete(downloads.keys().next().value);
  return id;
}

const hex = z.string().regex(/^#?[0-9a-fA-F]{6}$/).transform(v => (v.startsWith('#') ? v : '#' + v));
const imageInput = {
  image_url: z.string().optional().describe('Public URL (or data: URL) of the image'),
  image_base64: z.string().optional().describe('Base64 image data (PNG/JPG/WEBP), with or without data: prefix')
};
async function needImage(args) {
  const buf = await loadImage({ url: args.image_url, base64: args.image_base64 });
  if (!buf) throw new Error('Provide image_url or image_base64');
  return buf;
}
const preview = async (buf, max = 512) => ({ type: 'image', mimeType: 'image/png', data: (await sharp(buf).resize(max, max, { fit: 'inside', withoutEnlargement: true }).png().toBuffer()).toString('base64') });
const imageResult = async (buf, text) => {
  const m = await sharp(buf).metadata();
  return { content: [{ type: 'text', text: `${text} (${m.width}x${m.height}px). Full PNG is in the second item.` }, { type: 'image', mimeType: 'image/png', data: buf.toString('base64') }] };
};

export function createServer({ baseUrl } = {}) {
  const server = new McpServer({ name: 'mnasati-assets', version: '1.0.0' }, { instructions: 'Mnasati store asset tools for any MCP client: generate favicon/logo/def/bg/cover from a logo image (PNG/JPEG), trim, resize and remove regions.' });

  server.registerTool('generate_store_assets', {
    title: 'Generate Mnasati store assets',
    description: 'Create the Mnasati store asset pack from a logo: favicon.ico (192 circle), logo.png (350 circle), def.png (1000x1000), bg.jpg (533x1080 pattern at 5% opacity) and cover.jpg (1920x1080). Returns previews and a zip.',
    inputSchema: {
      store_name: z.string().optional(),
      ...imageInput,
      cover_image_url: z.string().optional(),
      cover_image_base64: z.string().optional(),
      store_color: hex.optional(),
      background_color: z.string().optional().describe("#RRGGBB or 'none' for transparent logo/def"),
      cover_color: hex.optional()
    }
  }, async (args) => {
    const logo = await needImage(args);
    const coverImg = await loadImage({ url: args.cover_image_url, base64: args.cover_image_base64 });
    let bgc = args.background_color || '#ffffff';
    if (/^[0-9a-fA-F]{6}$/.test(bgc)) bgc = '#' + bgc;
    const { name, files, fevPng, zipBuf } = await generateAssets({ storeName: args.store_name, logo, coverImg, backgroundColor: bgc, coverColor: args.cover_color });
    const fileName = `${name}_assets.zip`;
    const id = keepDownload(fileName, zipBuf);
    const link = baseUrl ? `${baseUrl}/download/${id}` : null;
    const list = Object.keys(files).join(', ');
    const content = [
      { type: 'text', text: `Generated ${Object.keys(files).length} files: ${list}.` + (link ? `\nDownload zip: ${link}` : '') + (args.store_color ? `\nStore color: ${args.store_color}` : '') },
      await preview(fevPng, 192),
      await preview(files[`${name}_logo.png`], 350),
      await preview(files[`${name}_def.png`], 400),
      await preview(files[`${name}_cover.jpg`], 640),
      { type: 'resource', resource: { uri: link || `mnasati://assets/${id}`, mimeType: 'application/zip', blob: zipBuf.toString('base64') } }
    ];
    return { content, structuredContent: { files: Object.keys(files), download_url: link } };
  });

  server.registerTool('trim_image', {
    title: 'Trim empty space',
    description: 'Remove transparent or uniform-color borders around an image.',
    inputSchema: { ...imageInput, threshold: z.number().min(0).max(255).optional(), padding: z.number().int().min(0).optional() }
  }, async (args) => imageResult(await trimImage(await needImage(args), args.threshold ?? 20, args.padding ?? 0), 'Trimmed image'));

  server.registerTool('resize_image', {
    title: 'Resize image',
    description: 'Resize an image to width x height with optional padding and background color.',
    inputSchema: { ...imageInput, width: z.number().int().min(1).max(6000), height: z.number().int().min(1).max(6000), fit: z.enum(['contain', 'cover', 'fill']).optional(), padding: z.number().int().min(0).optional(), background: z.string().optional().describe("#RRGGBB or 'none'") }
  }, async (args) => imageResult(await resizeImage(await needImage(args), args), 'Resized image'));

  server.registerTool('remove_region', {
    title: 'Remove a region',
    description: 'Make a rectangular region of the image transparent (x, y, width, height in pixels).',
    inputSchema: { ...imageInput, x: z.number(), y: z.number(), width: z.number().positive(), height: z.number().positive() }
  }, async (args) => imageResult(await removeRegion(await needImage(args), args), 'Region removed'));

  return server;
}
