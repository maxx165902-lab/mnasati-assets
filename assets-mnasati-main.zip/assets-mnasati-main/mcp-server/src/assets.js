// Image logic ported from index.html (drawCircularImage, drawSquareImage, drawBackgroundGrid, drawCoverImage, canvasToICO)
import sharp from 'sharp';
import JSZip from 'jszip';

export const SIZES = { fev: 192, logo: 350, def: 1000, bg: { width: 533, height: 1080 }, cover: { width: 1920, height: 1080 } };

const isTransparent = (c) => !c || c === 'none' || c === 'transparent';

export async function loadImage({ url, base64 }) {
  if (base64) {
    const raw = base64.includes(',') && base64.startsWith('data:') ? base64.split(',')[1] : base64;
    return Buffer.from(raw, 'base64');
  }
  if (url) {
    if (url.startsWith('data:')) return Buffer.from(url.split(',')[1], 'base64');
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Could not download image (${res.status})`);
    return Buffer.from(await res.arrayBuffer());
  }
  return null;
}

async function meta(buf) { const m = await sharp(buf).metadata(); return { w: m.width, h: m.height }; }

function canvas(width, height, color) {
  return sharp({ create: { width, height, channels: 4, background: isTransparent(color) ? { r: 0, g: 0, b: 0, alpha: 0 } : color } });
}

// Image scaled to fit (contain) inside boxW x boxH, times factor, as PNG buffer
async function fitImage(buf, boxW, boxH, factor = 1) {
  const { w, h } = await meta(buf);
  const scale = Math.min(boxW / w, boxH / h) * factor;
  const sw = Math.max(1, Math.round(w * scale)), sh = Math.max(1, Math.round(h * scale));
  return { buf: await sharp(buf).ensureAlpha().resize(sw, sh, { fit: 'fill' }).png().toBuffer(), w: sw, h: sh };
}

const circleSvg = (size, fill) => Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="${fill}"/></svg>`);

// drawCircularImage: background circle + image (contain) clipped to circle
export async function circular(buf, size, background = '#ffffff') {
  const img = await fitImage(buf, size, size, 1);
  const layer = await canvas(size, size, null)
    .composite([{ input: img.buf, left: Math.round((size - img.w) / 2), top: Math.round((size - img.h) / 2) }])
    .png().toBuffer();
  const clipped = await sharp(layer).composite([{ input: circleSvg(size, '#000'), blend: 'dest-in' }]).png().toBuffer();
  const base = isTransparent(background) ? canvas(size, size, null) : sharp(circleSvg(size, background)).ensureAlpha();
  return base.composite([{ input: clipped }]).png().toBuffer();
}

// drawSquareImage
export async function square(buf, size, background = '#ffffff') {
  const img = await fitImage(buf, size, size, 1);
  return canvas(size, size, background)
    .composite([{ input: img.buf, left: Math.round((size - img.w) / 2), top: Math.round((size - img.h) / 2) }])
    .png().toBuffer();
}

// drawBackgroundGrid: 3 columns of square cells, image at 80% of cell, 5% opacity
export async function backgroundGrid(buf, width = 533, height = 1080, background = '#ffffff') {
  const cols = 3, cell = width / cols, rows = Math.ceil(height / cell);
  const img = await fitImage(buf, cell, cell, 0.8);
  const faded = await sharp(img.buf).ensureAlpha().linear([1, 1, 1, 0.05], [0, 0, 0, 0]).png().toBuffer();
  const comps = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const left = Math.round(c * cell + (cell - img.w) / 2), top = Math.round(r * cell + (cell - img.h) / 2);
    if (top + img.h <= 0 || top >= height) continue;
    if (top < 0 || top + img.h > height || left + img.w > width) {
      // clip tiles that cross the canvas edge
      const ct = Math.max(0, -top), cl = Math.max(0, -left);
      const cw = Math.min(img.w - cl, width - Math.max(0, left)), ch = Math.min(img.h - ct, height - Math.max(0, top));
      if (cw <= 0 || ch <= 0) continue;
      comps.push({ input: await sharp(faded).extract({ left: cl, top: ct, width: cw, height: ch }).toBuffer(), left: Math.max(0, left), top: Math.max(0, top) });
    } else comps.push({ input: faded, left, top });
  }
  return canvas(width, height, isTransparent(background) ? '#ffffff' : background).composite(comps).flatten({ background: isTransparent(background) ? '#ffffff' : background }).jpeg({ quality: 92 }).toBuffer();
}

// drawCoverImage: cover image fills (cover fit); else logo at 50% centered on cover color
export async function cover(coverBuf, logoBuf, width = 1920, height = 1080, background = '#ffffff', coverColor = null) {
  const bg = isTransparent(background) ? '#ffffff' : background;
  if (coverBuf) {
    return sharp(coverBuf).resize(width, height, { fit: 'cover', position: 'centre' }).flatten({ background: bg }).jpeg({ quality: 92 }).toBuffer();
  }
  const fill = coverColor && coverColor.toLowerCase() !== bg.toLowerCase() ? coverColor : bg;
  const comps = [];
  if (logoBuf) {
    const img = await fitImage(logoBuf, width * 0.5, height * 0.5, 1);
    comps.push({ input: img.buf, left: Math.round((width - img.w) / 2), top: Math.round((height - img.h) / 2) });
  }
  return canvas(width, height, fill).composite(comps).flatten({ background: fill }).jpeg({ quality: 92 }).toBuffer();
}

// canvasToICO: ICO containing PNG images at 16, 32, 64, 192
export async function toIco(pngBuf, sizes = [16, 32, 64, 192]) {
  const pngs = await Promise.all(sizes.map(s => sharp(pngBuf).resize(s, s).png().toBuffer()));
  const header = Buffer.alloc(6); header.writeUInt16LE(0, 0); header.writeUInt16LE(1, 2); header.writeUInt16LE(sizes.length, 4);
  const dir = Buffer.alloc(16 * sizes.length);
  let offset = 6 + dir.length;
  sizes.forEach((s, i) => {
    const o = i * 16;
    dir.writeUInt8(s >= 256 ? 0 : s, o); dir.writeUInt8(s >= 256 ? 0 : s, o + 1);
    dir.writeUInt8(0, o + 2); dir.writeUInt8(0, o + 3); dir.writeUInt16LE(1, o + 4); dir.writeUInt16LE(32, o + 6);
    dir.writeUInt32LE(pngs[i].length, o + 8); dir.writeUInt32LE(offset, o + 12); offset += pngs[i].length;
  });
  return Buffer.concat([header, dir, ...pngs]);
}

export async function generateAssets({ storeName = 'store', logo, coverImg = null, backgroundColor = '#ffffff', coverColor = null }) {
  const name = (storeName || 'store').replace(/[^\w\u0600-\u06FF-]+/g, '_');
  const fevPng = await circular(logo, SIZES.fev, backgroundColor);
  const files = {
    [`${name}_favicon.ico`]: await toIco(fevPng),
    [`${name}_logo.png`]: await circular(logo, SIZES.logo, backgroundColor),
    [`${name}_def.png`]: await square(logo, SIZES.def, backgroundColor),
    [`${name}_bg.jpg`]: await backgroundGrid(logo, SIZES.bg.width, SIZES.bg.height, backgroundColor),
    [`${name}_cover.jpg`]: await cover(coverImg, logo, SIZES.cover.width, SIZES.cover.height, backgroundColor, coverColor)
  };
  const zip = new JSZip();
  for (const [f, b] of Object.entries(files)) zip.file(f, b);
  const zipBuf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  return { name, files, fevPng, zipBuf };
}

// Helpers
export async function trimImage(buf, threshold = 20, padding = 0) {
  let out = await sharp(buf).ensureAlpha().trim({ threshold }).png().toBuffer();
  if (padding > 0) out = await sharp(out).extend({ top: padding, bottom: padding, left: padding, right: padding, background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
  return out;
}

export async function resizeImage(buf, { width, height, fit = 'contain', padding = 0, background = 'none' }) {
  const bg = isTransparent(background) ? { r: 0, g: 0, b: 0, alpha: 0 } : background;
  const iw = Math.max(1, width - 2 * padding), ih = Math.max(1, height - 2 * padding);
  const inner = await sharp(buf).ensureAlpha().resize(iw, ih, { fit, background: bg }).png().toBuffer();
  return canvas(width, height, background).composite([{ input: inner, left: padding, top: padding }]).png().toBuffer();
}

export async function removeRegion(buf, { x, y, width, height }) {
  const { data, info } = await sharp(buf).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
  const x1 = Math.min(info.width, Math.floor(x + width)), y1 = Math.min(info.height, Math.floor(y + height));
  for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) data[(yy * info.width + xx) * 4 + 3] = 0;
  return sharp(data, { raw: { width: info.width, height: info.height, channels: 4 } }).png().toBuffer();
}
