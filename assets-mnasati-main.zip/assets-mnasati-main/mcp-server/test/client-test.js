// Run with the server started (npm start). Usage: node test/client-test.js [http://localhost:3000/mcp]
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import JSZip from 'jszip';
import sharp from 'sharp';

const url = process.argv[2] || 'http://localhost:3000/mcp';
const client = new Client({ name: 'test', version: '1.0.0' });
await client.connect(new StreamableHTTPClientTransport(new URL(url)));
const { tools } = await client.listTools();
console.log('tools:', tools.map(t => t.name).join(', '));

const logo = await sharp({ create: { width: 600, height: 300, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } })
  .composite([{ input: Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="300"><rect x="150" y="50" width="300" height="200" rx="40" fill="#e63946"/></svg>') }])
  .png().toBuffer();
const r = await client.callTool({ name: 'generate_store_assets', arguments: { store_name: 'test', image_base64: logo.toString('base64'), background_color: '#ffffff', cover_color: '#1d3557' } });
if (r.isError) throw new Error(JSON.stringify(r.content));
console.log(r.content[0].text);
const res = r.content.find(c => c.type === 'resource');
const zip = await JSZip.loadAsync(Buffer.from(res.resource.blob, 'base64'));
const expect = { favicon: [192, 192], logo: [350, 350], def: [1000, 1000], bg: [533, 1080], cover: [1920, 1080] };
let ok = Object.keys(zip.files).length === 5;
for (const f of Object.keys(zip.files)) {
  const buf = await zip.file(f).async('nodebuffer');
  const key = f.split('_').pop().split('.')[0];
  let w, h, fmt;
  if (f.endsWith('.ico')) { const n = buf.readUInt16LE(4); const last = (n - 1) * 16 + 6; const off = buf.readUInt32LE(last + 12); const m = await sharp(buf.subarray(off)).metadata(); w = m.width; h = m.height; fmt = `ico(${n} sizes)`; }
  else { const m = await sharp(buf).metadata(); w = m.width; h = m.height; fmt = m.format; }
  const good = expect[key][0] === w && expect[key][1] === h;
  ok = ok && good;
  console.log(`${good ? 'OK ' : 'BAD'} ${f} ${w}x${h} ${fmt}`);
}
const link = r.structuredContent?.download_url;
if (link) { const d = await fetch(link); console.log('download link', d.status, d.headers.get('content-type')); ok = ok && d.ok; }
const t = await client.callTool({ name: 'trim_image', arguments: { image_base64: logo.toString('base64') } });
console.log('trim:', t.content[0].text);
const rz = await client.callTool({ name: 'resize_image', arguments: { image_base64: logo.toString('base64'), width: 500, height: 500, padding: 20, background: '#ffffff' } });
console.log('resize:', rz.content[0].text);
const rr = await client.callTool({ name: 'remove_region', arguments: { image_base64: logo.toString('base64'), x: 150, y: 50, width: 100, height: 100 } });
const px = await sharp(Buffer.from(rr.content[1].data, 'base64')).raw().ensureAlpha().toBuffer({ resolveWithObject: true });
const alpha = px.data[(100 * px.info.width + 200) * 4 + 3];
console.log('remove_region alpha at (200,100):', alpha); ok = ok && alpha === 0;
await client.close();
console.log(ok ? 'ALL PASSED' : 'FAILED'); process.exit(ok ? 0 : 1);
