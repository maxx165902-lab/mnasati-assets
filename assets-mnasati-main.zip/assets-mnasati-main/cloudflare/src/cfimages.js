// Asset rendering with the Cloudflare Images binding (native resize/compose/encode, so Worker CPU stays low).
// Mirrors index.html: drawCircularImage, drawSquareImage, drawBackgroundGrid, drawCoverImage, canvasToICO.
import { zipSync } from 'fflate';
import { create, drawOver, circleMask, encodePng, parseColor, decode, fit, limit } from './image.js';

const stream = (u8) => new Blob([u8]).stream();
const hex = (rgb) => '#' + rgb.map(v => v.toString(16).padStart(2, '0')).join('');
const bytes = async (res) => new Uint8Array(await new Response(res.image()).arrayBuffer());

// 1x1 pixel of a color (or transparent), stretched by Images to the target size
const solidCache = new Map();
async function solid(rgb) {
  const k = rgb ? rgb.join() : 'none';
  if (!solidCache.has(k)) solidCache.set(k, await encodePng(create(4, 4, rgb)));
  return solidCache.get(k);
}
// size of the logo when contain-fitted into a box * factor (like the canvas code)
const fitSize = (w, h, bw, bh, f = 1) => { const s = Math.min(bw / w, bh / h) * f; return [Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))]; };

async function layered(IMAGES, W, H, rgb, layers, format = 'image/png') {
  let t = IMAGES.input(stream(await solid(rgb))).transform({ width: W, height: H, fit: 'squeeze' });
  for (const L of layers) t = t.draw(L.transform ? IMAGES.input(stream(L.src)).transform(L.transform) : stream(L.src), L.opts);
  return bytes(await t.output({ format, ...(format === 'image/jpeg' ? { quality: 90 } : {}) }));
}

async function circle(IMAGES, logoBytes, info, size, bg) {
  const [w, h] = fitSize(info.width, info.height, size, size);
  if (!bg) { // transparent background: clip in JS (small sizes only)
    const logo = limit(await decode(logoBytes), 800), out = create(size, size, null), img = fit(logo, size, size);
    return encodePng(drawOver(out, img, (size - img.w) / 2, (size - img.h) / 2, 1, circleMask(size)));
  }
  // Images can't clip, so paint the corners back to transparent afterwards in JS
  const flat = await layered(IMAGES, size, size, bg, [
    { src: logoBytes, transform: { width: w, height: h, fit: 'squeeze' }, opts: { left: Math.round((size - w) / 2), top: Math.round((size - h) / 2) } }
  ]);
  const img = await decode(flat), inside = circleMask(size), d = img.data;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) { const c = inside(x, y); if (c < 1) d[(y * size + x) * 4 + 3] *= c; }
  return encodePng(img);
}

async function ico(IMAGES, png192) {
  const sizes = [16, 32, 64, 192];
  const pngs = await Promise.all(sizes.map(async s => s === 192 ? png192 : bytes(await IMAGES.input(stream(png192)).transform({ width: s, height: s, fit: 'squeeze' }).output({ format: 'image/png' }))));
  const head = new Uint8Array(6 + 16 * sizes.length), dv = new DataView(head.buffer);
  dv.setUint16(2, 1, true); dv.setUint16(4, sizes.length, true);
  let off = head.length;
  sizes.forEach((s, i) => {
    const o = 6 + i * 16; head[o] = s; head[o + 1] = s;
    dv.setUint16(o + 4, 1, true); dv.setUint16(o + 6, 32, true); dv.setUint32(o + 8, pngs[i].length, true); dv.setUint32(o + 12, off, true); off += pngs[i].length;
  });
  const out = new Uint8Array(off); out.set(head); let p = head.length; for (const b of pngs) { out.set(b, p); p += b.length; }
  return out;
}

export async function generateAssetsCF(IMAGES, { storeName, logoBytes, coverBytes, backgroundColor = '#ffffff', coverColor }) {
  const name = (storeName || 'store').replace(/[^\w\u0600-\u06FF-]+/g, '_');
  const bg = parseColor(backgroundColor), cc = parseColor(coverColor || null), flat = bg || [255, 255, 255];
  const info = await IMAGES.info(stream(logoBytes));
  if (!info.width) throw new Error('Unsupported logo image (use PNG, JPEG or WebP)');
  const center = (W, H, bw, bh, f = 1) => { const [w, h] = fitSize(info.width, info.height, bw, bh, f); return { src: logoBytes, transform: { width: w, height: h, fit: 'squeeze' }, opts: { left: Math.round((W - w) / 2), top: Math.round((H - h) / 2) } }; };

  // bg grid: 3 columns of square cells, logo at 80% of a cell, 5% opacity
  // (Images allows max 10 draws per call: build one transparent row of 3 tiles, then stack the rows)
  const W = 533, H = 1080, cell = W / 3, rows = Math.ceil(H / cell), [tw, th] = fitSize(info.width, info.height, cell, cell, 0.8);
  const rowH = Math.round(cell);
  const row = await layered(IMAGES, W, rowH, null, [0, 1, 2].map(c => ({ src: logoBytes, transform: { width: tw, height: th, fit: 'squeeze' }, opts: { left: Math.round(c * cell + (cell - tw) / 2), top: Math.round((cell - th) / 2), opacity: 0.05 } })));
  const tallH = rows * rowH;
  const tall = await layered(IMAGES, W, tallH, flat, Array.from({ length: rows }, (_, r) => ({ src: row, transform: null, opts: { left: 0, top: r * rowH } })), tallH === H ? 'image/jpeg' : 'image/png');
  const bgJpg = tallH === H ? tall : await bytes(await IMAGES.input(stream(tall)).transform({ width: W, height: H, fit: 'crop', gravity: 'top' }).output({ format: 'image/jpeg', quality: 90 }));

  const coverFill = cc && cc.join() !== flat.join() ? cc : flat;
  const coverJpg = coverBytes
    ? await bytes(await IMAGES.input(stream(coverBytes)).transform({ width: 1920, height: 1080, fit: 'cover', background: hex(flat) }).output({ format: 'image/jpeg', quality: 90 }))
    : await layered(IMAGES, 1920, 1080, coverFill, [center(1920, 1080, 960, 540)], 'image/jpeg');

  const fev = await circle(IMAGES, logoBytes, info, 192, bg);
  const logoPng = await circle(IMAGES, logoBytes, info, 350, bg);
  const defPng = await layered(IMAGES, 1000, 1000, bg, [center(1000, 1000, 1000, 1000)]);

  const files = {
    [`${name}_favicon.ico`]: await ico(IMAGES, fev),
    [`${name}_logo.png`]: logoPng,
    [`${name}_def.png`]: defPng,
    [`${name}_bg.jpg`]: bgJpg,
    [`${name}_cover.jpg`]: coverJpg
  };
  const zip = zipSync(Object.fromEntries(Object.entries(files).map(([k, v]) => [k, [v, { level: 0 }]])));
  const coverPreview = await bytes(await IMAGES.input(stream(coverJpg)).transform({ width: 640 }).output({ format: 'image/jpeg', quality: 80 }));
  return { name, files, zip, previews: [{ mime: 'image/png', data: logoPng }, { mime: 'image/jpeg', data: coverPreview }] };
}

// resize_image with Images: exact canvas W x H, optional padding and background
export async function resizeCF(IMAGES, srcBytes, { width: W, height: H, fit: f = 'contain', padding: p = 0, background = 'none' }) {
  const info = await IMAGES.info(stream(srcBytes));
  const iw = Math.max(1, W - 2 * p), ih = Math.max(1, H - 2 * p);
  let layer;
  if (f === 'fill') layer = { src: srcBytes, transform: { width: iw, height: ih, fit: 'squeeze' }, opts: { left: p, top: p } };
  else if (f === 'cover') layer = { src: srcBytes, transform: { width: iw, height: ih, fit: 'cover' }, opts: { left: p, top: p } };
  else { const [w, h] = fitSize(info.width, info.height, iw, ih); layer = { src: srcBytes, transform: { width: w, height: h, fit: 'squeeze' }, opts: { left: p + Math.round((iw - w) / 2), top: p + Math.round((ih - h) / 2) } }; }
  return layered(IMAGES, W, H, parseColor(background), [layer]);
}
