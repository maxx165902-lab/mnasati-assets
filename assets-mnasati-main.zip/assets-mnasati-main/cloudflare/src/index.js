// Mnasati Assets on Cloudflare Workers: static page + stateless MCP (Streamable HTTP, JSON responses) at /mcp
import { decode, limit, encodePng, trim, pad, clearRect } from './image.js';
import { generateAssetsCF, resizeCF } from './cfimages.js';

const PROTOCOLS = ['2025-06-18', '2025-03-26', '2024-11-05'];
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, Mcp-Session-Id, Mcp-Protocol-Version',
  'Access-Control-Expose-Headers': 'Mcp-Session-Id'
};
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', ...CORS } });

const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s) => { const bin = atob(s.replace(/^data:[^,]*,/, '').replace(/\s/g, '')); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };

const imageProps = {
  image_url: { type: 'string', description: 'Public URL (or data: URL) of a PNG/JPEG image' },
  image_base64: { type: 'string', description: 'Base64 PNG/JPEG data, with or without data: prefix' }
};
const TOOLS = [
  {
    name: 'generate_store_assets', title: 'Generate Mnasati store assets',
    description: 'Create the Mnasati store asset pack from a logo: favicon.ico (192 circle), logo.png (350 circle), def.png (1000x1000), bg.jpg (533x1080 pattern at 5% opacity), cover.jpg (1920x1080). Returns previews, a zip download link and the zip as an embedded resource.',
    inputSchema: { type: 'object', properties: {
      store_name: { type: 'string' }, ...imageProps,
      cover_image_url: { type: 'string' }, cover_image_base64: { type: 'string' },
      background_color: { type: 'string', description: "#RRGGBB (default #ffffff) or 'none' for transparent logo/def" },
      cover_color: { type: 'string', description: '#RRGGBB color behind the logo on the cover' }
    } }
  },
  { name: 'trim_image', title: 'Trim empty space', description: 'Remove transparent or uniform-color borders around an image.',
    inputSchema: { type: 'object', properties: { ...imageProps, threshold: { type: 'number', minimum: 0, maximum: 255 }, padding: { type: 'integer', minimum: 0 } } } },
  { name: 'resize_image', title: 'Resize image', description: 'Resize an image to width x height with optional padding and background color.',
    inputSchema: { type: 'object', required: ['width', 'height'], properties: { ...imageProps, width: { type: 'integer', minimum: 1, maximum: 4000 }, height: { type: 'integer', minimum: 1, maximum: 4000 }, fit: { type: 'string', enum: ['contain', 'cover', 'fill'] }, padding: { type: 'integer', minimum: 0 }, background: { type: 'string', description: "#RRGGBB or 'none'" } } } },
  { name: 'remove_region', title: 'Remove a region', description: 'Make a rectangular region transparent (pixels).',
    inputSchema: { type: 'object', required: ['x', 'y', 'width', 'height'], properties: { ...imageProps, x: { type: 'number' }, y: { type: 'number' }, width: { type: 'number' }, height: { type: 'number' } } } }
];

async function loadBytes(url, base64) {
  if (base64) return unb64(base64);
  if (url) {
    if (url.startsWith('data:')) return unb64(url);
    const r = await fetch(url, { headers: { 'User-Agent': 'mnasati-assets-mcp' } });
    if (!r.ok) throw new Error(`Could not download image (${r.status})`);
    return new Uint8Array(await r.arrayBuffer());
  }
  return null;
}
async function needImage(a) {
  const bytes = await loadBytes(a.image_url, a.image_base64);
  if (!bytes) throw new Error('Provide image_url or image_base64');
  return limit(await decode(bytes), 1000);
}
const imgContent = async (img) => ({ type: 'image', mimeType: 'image/png', data: b64(await encodePng(img)) });
const imgResult = async (img, text) => ({ content: [{ type: 'text', text: `${text} (${img.w}x${img.h}px). PNG attached.` }, await imgContent(img)] });

async function callTool(name, a = {}, env, origin) {
  switch (name) {
    case 'generate_store_assets': {
      const logoBytes = await loadBytes(a.image_url, a.image_base64);
      if (!logoBytes) throw new Error('Provide image_url or image_base64');
      const coverBytes = await loadBytes(a.cover_image_url, a.cover_image_base64);
      const { name: n, files, zip, previews } = await generateAssetsCF(env.IMAGES, { storeName: a.store_name, logoBytes, coverBytes, backgroundColor: a.background_color || '#ffffff', coverColor: a.cover_color });
      const fileName = `${n}_assets.zip`;
      let link = null;
      if (env.DOWNLOADS) {
        const id = crypto.randomUUID();
        await env.DOWNLOADS.put(`${id}.zip`, zip, { httpMetadata: { contentType: 'application/zip', contentDisposition: `attachment; filename="${encodeURIComponent(fileName)}"` } });
        link = `${origin}/download/${id}`;
      }
      const list = Object.keys(files);
      return {
        content: [
          { type: 'text', text: `Generated ${list.length} files: ${list.join(', ')}.` + (link ? `\nDownload zip: ${link}` : '') },
          ...previews.map(p => ({ type: 'image', mimeType: p.mime, data: b64(p.data) })),
          { type: 'resource', resource: { uri: link || `mnasati://assets/${fileName}`, mimeType: 'application/zip', blob: b64(zip) } }
        ],
        structuredContent: { files: list, download_url: link }
      };
    }
    case 'trim_image': {
      let img = trim(await needImage(a), a.threshold ?? 20);
      if (a.padding > 0) img = pad(img, a.padding);
      return imgResult(img, 'Trimmed image');
    }
    case 'resize_image': {
      const srcBytes = await loadBytes(a.image_url, a.image_base64);
      if (!srcBytes) throw new Error('Provide image_url or image_base64');
      const png = await resizeCF(env.IMAGES, srcBytes, a);
      return { content: [{ type: 'text', text: `Resized image (${a.width}x${a.height}px). PNG attached.` }, { type: 'image', mimeType: 'image/png', data: b64(png) }] };
    }
    case 'remove_region':
      return imgResult(clearRect(await needImage(a), a.x, a.y, a.width, a.height), 'Region removed');
    default: {
      const e = new Error(`Unknown tool: ${name}`); e.code = -32602; throw e;
    }
  }
}

async function handleRpc(msg, env, origin) {
  const { id, method, params = {} } = msg || {};
  if (id === undefined || id === null) return null; // notification
  const ok = (result) => ({ jsonrpc: '2.0', id, result });
  const err = (code, message) => ({ jsonrpc: '2.0', id, error: { code, message } });
  switch (method) {
    case 'initialize':
      return ok({ protocolVersion: PROTOCOLS.includes(params.protocolVersion) ? params.protocolVersion : PROTOCOLS[0], capabilities: { tools: { listChanged: false } }, serverInfo: { name: 'mnasati-assets', version: '1.0.0' }, instructions: 'Mnasati store asset tools for any MCP client: generate favicon/logo/def/bg/cover from a logo image (PNG/JPEG), trim, resize and remove regions.' });
    case 'ping': return ok({});
    case 'tools/list': return ok({ tools: TOOLS });
    case 'resources/list': return ok({ resources: [] });
    case 'prompts/list': return ok({ prompts: [] });
    case 'tools/call':
      try { return ok(await callTool(params.name, params.arguments, env, origin)); }
      catch (e) { if (e.code === -32602) return err(e.code, e.message); return ok({ isError: true, content: [{ type: 'text', text: `Error: ${e.message}` }] }); }
    default: return err(-32601, `Method not found: ${method}`);
  }
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    if (url.pathname === '/mcp') {
      if (req.method !== 'POST') return json({ jsonrpc: '2.0', error: { code: -32000, message: 'Method not allowed.' }, id: null }, 405);
      if (env.AUTH_TOKEN) {
        const h = req.headers.get('Authorization') || '';
        if (h !== `Bearer ${env.AUTH_TOKEN}` && url.searchParams.get('token') !== env.AUTH_TOKEN) return json({ jsonrpc: '2.0', error: { code: -32001, message: 'Unauthorized' }, id: null }, 401);
      }
      let body;
      try { body = await req.json(); } catch { return json({ jsonrpc: '2.0', error: { code: -32700, message: 'Parse error' }, id: null }, 400); }
      const batch = Array.isArray(body);
      const out = (await Promise.all((batch ? body : [body]).map(m => handleRpc(m, env, url.origin)))).filter(Boolean);
      if (!out.length) return new Response(null, { status: 202, headers: CORS });
      return json(batch ? out : out[0]);
    }

    const dl = url.pathname.match(/^\/download\/([0-9a-f-]{36})$/);
    if (dl) {
      const obj = env.DOWNLOADS && await env.DOWNLOADS.get(`${dl[1]}.zip`);
      if (!obj) return new Response('Not found or expired', { status: 404 });
      const headers = new Headers(CORS); obj.writeHttpMetadata(headers);
      return new Response(obj.body, { headers });
    }
    if (url.pathname === '/health') return json({ ok: true });
    return env.ASSETS.fetch(req);
  }
};
