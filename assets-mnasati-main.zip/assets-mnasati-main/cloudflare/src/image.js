// Pure-JS raster helpers (no native deps) so they run on Cloudflare Workers.
import jpeg from 'jpeg-js';

// PNG encode/decode use the runtime's native (C++) zlib via CompressionStream to keep Worker CPU time low.
async function zlib(bytes, mode) {
  const stream = new Blob([bytes]).stream().pipeThrough(mode === 'c' ? new CompressionStream('deflate') : new DecompressionStream('deflate'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(u8, start, end) { let c = 0xffffffff; for (let i = start; i < end; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }

export async function encodePng(img) {
  const { w, h, data } = img, stride = w * 4;
  const raw = new Uint8Array((stride + 1) * h);
  const src = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  for (let y = 0; y < h; y++) raw.set(src.subarray(y * stride, (y + 1) * stride), y * (stride + 1) + 1);
  const idat = await zlib(raw, 'c');
  const chunks = [];
  const chunk = (type, body) => {
    const c = new Uint8Array(12 + body.length), dv = new DataView(c.buffer);
    dv.setUint32(0, body.length); for (let i = 0; i < 4; i++) c[4 + i] = type.charCodeAt(i);
    c.set(body, 8); dv.setUint32(8 + body.length, crc32(c, 4, 8 + body.length)); chunks.push(c);
  };
  const ihdr = new Uint8Array(13), dv = new DataView(ihdr.buffer);
  dv.setUint32(0, w); dv.setUint32(4, h); ihdr[8] = 8; ihdr[9] = 6;
  chunk('IHDR', ihdr); chunk('IDAT', idat); chunk('IEND', new Uint8Array(0));
  const sig = [137, 80, 78, 71, 13, 10, 26, 10];
  const out = new Uint8Array(8 + chunks.reduce((a, c) => a + c.length, 0)); out.set(sig); let p = 8;
  for (const c of chunks) { out.set(c, p); p += c.length; }
  return out;
}

async function decodePng(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let p = 8, w, h, depth, ctype, interlace, palette = null, trns = null; const idat = [];
  while (p < u8.length) {
    const len = dv.getUint32(p), type = String.fromCharCode(u8[p + 4], u8[p + 5], u8[p + 6], u8[p + 7]), body = u8.subarray(p + 8, p + 8 + len);
    if (type === 'IHDR') { w = dv.getUint32(p + 8); h = dv.getUint32(p + 12); depth = u8[p + 16]; ctype = u8[p + 17]; interlace = u8[p + 20]; }
    else if (type === 'PLTE') palette = body; else if (type === 'tRNS') trns = body; else if (type === 'IDAT') idat.push(body); else if (type === 'IEND') break;
    p += 12 + len;
  }
  if (interlace) throw new Error('Interlaced PNG is not supported; please re-save the image');
  const ch = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[ctype];
  const bpp = Math.max(1, (ch * depth) >> 3), stride = Math.ceil((w * ch * depth) / 8);
  const joined = new Uint8Array(idat.reduce((a, b) => a + b.length, 0)); let o = 0; for (const b of idat) { joined.set(b, o); o += b.length; }
  const raw = await zlib(joined, 'd');
  const px = new Uint8Array(stride * h);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)], line = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1)), cur = y * stride, prev = cur - stride;
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? px[cur + x - bpp] : 0, b = y ? px[prev + x] : 0, c = x >= bpp && y ? px[prev + x - bpp] : 0;
      let v = line[x];
      if (f === 1) v += a; else if (f === 2) v += b; else if (f === 3) v += (a + b) >> 1;
      else if (f === 4) { const pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
      px[cur + x] = v;
    }
  }
  const out = new Uint8ClampedArray(w * h * 4);
  const sample = (row, i) => {
    if (depth === 8) return px[row + i];
    if (depth === 16) return px[row + i * 2];
    const bitPos = i * depth, byte = px[row + (bitPos >> 3)], shift = 8 - depth - (bitPos & 7);
    return (byte >> shift) & ((1 << depth) - 1);
  };
  const scale = depth < 8 && ctype !== 3 ? 255 / ((1 << depth) - 1) : 1;
  for (let y = 0; y < h; y++) {
    const row = y * stride;
    for (let x = 0; x < w; x++) {
      const q = (y * w + x) * 4;
      if (ctype === 6 || ctype === 2) { for (let k = 0; k < ch; k++) out[q + k] = sample(row, x * ch + k); if (ctype === 2) out[q + 3] = 255; }
      else if (ctype === 0 || ctype === 4) { const g = sample(row, x * ch) * scale; out[q] = out[q + 1] = out[q + 2] = g; out[q + 3] = ctype === 4 ? sample(row, x * ch + 1) : 255; }
      else { const i = sample(row, x); out[q] = palette[i * 3]; out[q + 1] = palette[i * 3 + 1]; out[q + 2] = palette[i * 3 + 2]; out[q + 3] = trns && i < trns.length ? trns[i] : 255; }
    }
  }
  return { w, h, data: out };
}

export async function decode(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (u8[0] === 0x89 && u8[1] === 0x50) return decodePng(u8);
  if (u8[0] === 0xff && u8[1] === 0xd8) {
    const j = jpeg.decode(u8, { useTArray: true, formatAsRGBA: true, maxMemoryUsageInMB: 256 });
    return { w: j.width, h: j.height, data: new Uint8ClampedArray(j.data.buffer) };
  }
  throw new Error('Unsupported image format: send PNG or JPEG');
}

// Large inputs are shrunk first so every later step stays cheap
export function limit(img, max = 1200) {
  const s = Math.min(1, max / Math.max(img.w, img.h));
  return s < 1 ? resize(img, img.w * s, img.h * s) : img;
}

export function parseColor(c) {
  if (!c || c === 'none' || c === 'transparent') return null;
  const m = /^#?([0-9a-f]{6})$/i.exec(c.trim());
  if (!m) throw new Error(`Bad color "${c}" (use #RRGGBB or none)`);
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function create(w, h, rgb) {
  const data = new Uint8ClampedArray(w * h * 4);
  if (rgb) new Uint32Array(data.buffer).fill(((255 << 24) | (rgb[2] << 16) | (rgb[1] << 8) | rgb[0]) >>> 0);
  return { w, h, data };
}

// Area-average downscale / bilinear upscale with premultiplied alpha
export function resize(src, dw, dh) {
  dw = Math.max(1, Math.round(dw)); dh = Math.max(1, Math.round(dh));
  const { w: sw, h: sh, data: s } = src, out = new Uint8ClampedArray(dw * dh * 4);
  const sx = sw / dw, sy = sh / dh;
  if (sx >= 1 && sy >= 1) {
    for (let y = 0; y < dh; y++) {
      const y0 = Math.floor(y * sy), y1 = Math.min(sh, Math.max(y0 + 1, Math.floor((y + 1) * sy)));
      for (let x = 0; x < dw; x++) {
        const x0 = Math.floor(x * sx), x1 = Math.min(sw, Math.max(x0 + 1, Math.floor((x + 1) * sx)));
        let r = 0, g = 0, b = 0, a = 0, n = 0;
        for (let yy = y0; yy < y1; yy++) for (let xx = x0, i = (yy * sw + x0) * 4; xx < x1; xx++, i += 4) {
          const al = s[i + 3]; r += s[i] * al; g += s[i + 1] * al; b += s[i + 2] * al; a += al; n++;
        }
        const o = (y * dw + x) * 4;
        if (a > 0) { out[o] = r / a; out[o + 1] = g / a; out[o + 2] = b / a; }
        out[o + 3] = a / n;
      }
    }
  } else {
    for (let y = 0; y < dh; y++) {
      const fy = Math.min(sh - 1, Math.max(0, (y + 0.5) * sy - 0.5)), y0 = Math.floor(fy), y1 = Math.min(sh - 1, y0 + 1), ty = fy - y0;
      for (let x = 0; x < dw; x++) {
        const fx = Math.min(sw - 1, Math.max(0, (x + 0.5) * sx - 0.5)), x0 = Math.floor(fx), x1 = Math.min(sw - 1, x0 + 1), tx = fx - x0;
        const idx = [(y0 * sw + x0) * 4, (y0 * sw + x1) * 4, (y1 * sw + x0) * 4, (y1 * sw + x1) * 4];
        const wt = [(1 - tx) * (1 - ty), tx * (1 - ty), (1 - tx) * ty, tx * ty];
        let r = 0, g = 0, b = 0, a = 0;
        for (let k = 0; k < 4; k++) { const al = s[idx[k] + 3] * wt[k]; r += s[idx[k]] * al; g += s[idx[k] + 1] * al; b += s[idx[k] + 2] * al; a += al; }
        const o = (y * dw + x) * 4;
        if (a > 0) { out[o] = r / a; out[o + 1] = g / a; out[o + 2] = b / a; }
        out[o + 3] = a;
      }
    }
  }
  return { w: dw, h: dh, data: out };
}

// Source-over composite; optional opacity and per-destination-pixel mask(x,y)->0..1
export function drawOver(dst, src, left, top, opacity = 1, mask = null) {
  left = Math.round(left); top = Math.round(top);
  const xs = Math.max(0, -left), ys = Math.max(0, -top);
  const xe = Math.min(src.w, dst.w - left), ye = Math.min(src.h, dst.h - top);
  const d = dst.data, s = src.data;
  for (let y = ys; y < ye; y++) for (let x = xs; x < xe; x++) {
    const si = (y * src.w + x) * 4, dx = x + left, dy = y + top, di = (dy * dst.w + dx) * 4;
    let sa = (s[si + 3] / 255) * opacity;
    if (mask) sa *= mask(dx, dy);
    if (sa <= 0) continue;
    const da = d[di + 3] / 255, oa = sa + da * (1 - sa);
    for (let c = 0; c < 3; c++) d[di + c] = (s[si + c] * sa + d[di + c] * da * (1 - sa)) / oa;
    d[di + 3] = oa * 255;
  }
  return dst;
}

export const circleMask = (size) => { const r = size / 2; return (x, y) => { const dist = Math.hypot(x + 0.5 - r, y + 0.5 - r); return Math.min(1, Math.max(0, r - dist + 0.5)); }; };

export function fit(img, boxW, boxH, factor = 1) {
  const sc = Math.min(boxW / img.w, boxH / img.h) * factor;
  return resize(img, img.w * sc, img.h * sc);
}

export function trim(img, threshold = 20) {
  const { w, h, data } = img;
  const ref = [data[0], data[1], data[2], data[3]];
  const empty = (i) => data[i + 3] <= threshold || (ref[3] > 250 && Math.abs(data[i] - ref[0]) + Math.abs(data[i + 1] - ref[1]) + Math.abs(data[i + 2] - ref[2]) <= threshold * 3 && data[i + 3] > 250);
  let x0 = w, y0 = h, x1 = -1, y1 = -1;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (!empty((y * w + x) * 4)) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  if (x1 < 0) return img;
  return crop(img, x0, y0, x1 - x0 + 1, y1 - y0 + 1);
}
export function crop(img, x, y, cw, ch) {
  const out = create(cw, ch, null);
  for (let yy = 0; yy < ch; yy++) out.data.set(img.data.subarray(((y + yy) * img.w + x) * 4, ((y + yy) * img.w + x + cw) * 4), yy * cw * 4);
  return out;
}
export function pad(img, p, rgb = null) {
  const out = create(img.w + 2 * p, img.h + 2 * p, rgb);
  return drawOver(out, img, p, p);
}
export function clearRect(img, x, y, rw, rh) {
  const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y)), x1 = Math.min(img.w, Math.floor(x + rw)), y1 = Math.min(img.h, Math.floor(y + rh));
  for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) { const i = (yy * img.w + xx) * 4; img.data[i] = img.data[i + 1] = img.data[i + 2] = img.data[i + 3] = 0; }
  return img;
}
