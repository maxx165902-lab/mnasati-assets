# Mnasati Assets on Cloudflare Workers

Short URL: https://mnasati.pages.dev (MCP: https://mnasati.pages.dev/mcp, see ../pages)  
Live: https://mnasati-assets.maxx165902.workers.dev  ·  MCP: https://mnasati-assets.maxx165902.workers.dev/mcp

## العربية
- الصفحة والـ MCP على نفس الرابط. أضف رابط `/mcp` كخادم MCP / موصل في أي ذكاء اصطناعي يدعم MCP: ChatGPT (موصل مخصص، بدون مصادقة)، Claude (custom connector)، Cursor (`mcp.json`: `{"mcpServers":{"mnasati-assets":{"url":"<link>"}}}`) وغيرها. تختلف أسماء القوائم حسب التطبيق.
- للنشر من جديد: `npm install` ثم `npm run deploy`. هذا ينسخ `../index.html` إلى `public/` ثم ينفّذ `wrangler deploy`.

## English
- **Static page:** `public/` holds a copy of `../index.html` and the logo, made by `npm run build`.
- **MCP endpoint:** `POST /mcp` is stateless JSON-RPC (Streamable HTTP, JSON responses). `GET /mcp` returns 405. CORS is `*` with `OPTIONS` preflight, so any MCP client (ChatGPT, Claude, Cursor, browser-based tools) can connect.
- **Tools:** the same four as the Node server:
  - `generate_store_assets` and `resize_image` use the **Cloudflare Images binding** (`IMAGES`) for native resizing, compositing and PNG/JPEG encoding, which keeps Worker CPU low.
  - `trim_image` and `remove_region` are pure JS and accept PNG/JPEG.
- **Downloads:** zips go to R2 bucket `mnasati-assets-downloads` and are served at `/download/:id`. A lifecycle rule deletes them after 1 day.
- **Optional auth:** `npx wrangler secret put AUTH_TOKEN`. Clients then use `/mcp?token=...` or a Bearer header.
- **Images limits:** a single call allows at most 10 draws/transforms. On the free plan, Cloudflare Images includes a monthly quota of unique transformations; each generation uses about 15.
